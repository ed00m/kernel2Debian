#define UTS_RELEASE "3.10-2-amd64"
